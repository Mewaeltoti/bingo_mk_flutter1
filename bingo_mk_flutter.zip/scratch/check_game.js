const admin = require("firebase-admin");

if (!admin.apps.length) {
    admin.initializeApp();
}

async function run() {
    const db = admin.firestore();
    console.log("=== FIRESTORE games/live ===");
    try {
        const doc = await db.collection('games').doc('live').get();
        if (doc.exists) {
            const data = doc.data();
            console.log("Session ID:", data.sessionId);
            console.log("Status:", data.status);
            console.log("Is Paused:", data.isPaused);
            console.log("Winners:", data.winners);
            console.log("Pending Claims Count:", (data.pendingClaims || []).length);
            console.log("Status Message:", data.statusMessage);
        } else {
            console.log("games/live document does not exist!");
        }
    } catch (e) {
        console.error("Firestore read failed:", e.message);
    }

    console.log("\n=== REALTIME DATABASE games/live ===");
    try {
        const rtdbSnap = await admin.database().ref('games/live').once('value');
        const val = rtdbSnap.val();
        if (val) {
            console.log("Current Number:", val.currentNumber);
            console.log("Drawn Numbers Length:", val.drawnNumbers ? (Array.isArray(val.drawnNumbers) ? val.drawnNumbers.filter(e => e !== null).length : Object.keys(val.drawnNumbers).length) : 0);
            console.log("Drawn Numbers:", val.drawnNumbers);
            console.log("Last Draw Time:", val.lastDrawTime);
        } else {
            console.log("games/live ref is empty!");
        }
    } catch (e) {
        console.error("Realtime Database read failed:", e.message);
    }
    process.exit(0);
}

run();
